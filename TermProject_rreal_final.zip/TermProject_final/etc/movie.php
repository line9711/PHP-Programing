<? session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title3.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
<div id="wrap">
  <div id="header">
    <? include "../lib/top_menu.php"; ?>
  </div>  <!-- end of header -->
  <div id="title">동영상</div>
  <div id="video"><video src="../video/꿈을 만들어주는 독서_10분독서.avi" controls=true width=700px>

  </video></div>
  <div id="last">
    <? include "../lib/bottom_menu.php"; ?>
  </div>
</div> <!-- end of wrap -->

</body>
</html>
