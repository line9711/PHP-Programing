<?
      include "../lib/dbconn.php";

      $item_num = $_GET['item_num'];
      $ripple_num  = $_GET['ripple_num'];

      $table="free";
      $num=$_GET["num"];

      $sql = "delete from free_ripple where num=$ripple_num";
      mysql_query($sql, $connect);
      mysql_close();

      echo "
	   <script>
//	    location.href = 'view.php?table=$table&num=$num';
         location.href = 'view.php?table=$table&num=$num';  
	   </script>
	  ";
?>
