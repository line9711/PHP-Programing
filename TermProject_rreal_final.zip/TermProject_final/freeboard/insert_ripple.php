<?
   session_start();
?>
<meta charset="utf-8">
<?
$userid=$_SESSION["userid"];
$usernick = $_SESSION['usernick'];
$username = $_SESSION['username'];
$ripple_content = $_POST['ripple_content'];
$regist_day = $_POST['regist_day'];

$num=$_GET["num"];

$table="free";
$item_num=$_POST["item_num"];


   if(!$userid) {
     echo("
	   <script>
	     window.alert('로그인 후 이용하세요.')
	     history.go(-1)
	   </script>
	 ");
	 exit;
   }
   include "../lib/dbconn.php";       // dconn.php 파일을 불러옴

   $regist_day = date("Y-m-d (H:i)");  // 현재의 '년-월-일-시-분'을 저장

   // 레코드 삽입 명령 입력
   $sql = "insert into free_ripple (parent, id, name, nick, content, regist_day) ";
   $sql .= "values($num, '$userid', '$username', '$usernick', '$ripple_content', '$regist_day')";

   mysql_query($sql, $connect);  // $sql 에 저장된 명령 실행
   mysql_close();                // 데이터베이스와의 연결 종료

   echo "
	   <script>
	    location.href = 'view.php?table=$table&num=$num';  
	 </script>
	";
?>
