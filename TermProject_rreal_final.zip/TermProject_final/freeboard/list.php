<?
	session_start();
	$table = "free";
	$ripple = "free_ripple";
    $find=$_POST["find"];
	$nick = $_SESSION["usernick"];
	$page = $_GET["page"];

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/freeboardc.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title5.css" rel="stylesheet" type="text/css" media="all">
</head>
<?
	include "../lib/dbconn.php";
	$scale=10;			// 한 화면에 표시되는 글의 개수

    $mode=$_GET["mode"];         ////추가추가추가!!!!!
    if ($mode=="search")
	{
        $search=$_POST["search"];

		if(!$search)
		{
			echo("
				<script>
				 window.alert('검색할 단어를 입력하세요');
			     history.go(-1);
				</script>
			");
			exit;
		}
		$sql = "select * from $table where $find like '%$search%' order by num desc";
	}
	else
	{
		$sql = "select * from $table order by num desc";
	}

	$result = mysql_query($sql, $connect);
	$total_record = @mysql_num_rows($result); // 전체 글의 개수

	// 전체 페이지 수($total_page) 계산
	if ($total_record % $scale == 0)
		$total_page = floor($total_record/$scale);
	else
		$total_page = floor($total_record/$scale) + 1;

	if (!$page)
		$page = 1;


	$start = ($page - 1) * $scale;
	$number = $total_record - $start;
?>
<body>
	<div id="wrap">
	  <div id="header">
		<? include "../lib/top_menu.php"; ?>
	  </div>
		<div id="title">자유게시판</div>
  <div id="content">
	<div id="col2">

		<form  name="board_form" method="post" action="list.php?table=<?=$table?>&mode=search">
		<div id="list_search">
			<div id="list_search1">
				<img src="../image/화살표.png" height=10px/>&nbsp;
				총 <?= $total_record ?> 개의 게시물이 있습니다.  </div>
			<div id="list_search2"><img src="../image/select_search.gif"></div>
			<div id="list_search3">
				<select name="find">
                    <option value='subject'>제목</option>
                    <option value='content'>내용</option>
                    <option value='nick'>닉네임</option>
                    <option value='name'>이름</option>
				</select></div>
			<div id="list_search4"><input type="text" name="search" value=<?=$search?>></div>
			<div id="list_search5"><input type="image" src="../image/검색-1.png" height=25px></div>
		</div>
		</form>
		<div class="clear"></div>

		<div id="list_top_title">
			<ul>
				<li id="list_title1"><img src="../image/list_title1.gif"></li>
				<li id="list_title2"><img src="../image/list_title2.gif"></li>
				<li id="list_title3"><img src="../image/list_title3.gif"></li>
				<li id="list_title4"><img src="../image/list_title4.gif"></li>
				<li id="list_title5"><img src="../image/list_title5.gif"></li>
			</ul>
		</div>

		<div id="list_content">
<?
   for ($i=$start; $i<$start+$scale && $i < $total_record; $i++)
   {
      mysql_data_seek($result, $i);     // 레코드 지칭
      $row = mysql_fetch_array($result); // 하나의 레코드 가져오기

	  $item_num     = $row[num];
	  $item_id      = $row[id];
	  $item_name    = $row[name];
  	  $item_nick    = $row[nick];
	  $item_hit     = $row[hit];
      $item_date    = $row[regist_day];
	  $item_date = substr($item_date, 0, 10);
	  $item_subject = str_replace(" ", "&nbsp;", $row[subject]);

	  $sql = "select * from $ripple where parent=$item_num";
	  $result2 = mysql_query($sql, $connect);
	  $num_ripple = @mysql_num_rows($result2);

?>
			<div id="list_item">
				<div id="list_item1"><?= $number ?></div>
				<div id="list_item2"><a href="view.php?table=<?=$table?>&num=<?=$item_num?>&page=<?=$page?>"><?= $item_subject ?></a>
<?
		if ($num_ripple)
				echo " [$num_ripple]";
?>
				</div>
				<div id="list_item3"><?= $item_nick ?></div>
				<div id="list_item4"><?= $item_date ?></div>
				<div id="list_item5"><?= $item_hit ?></div>
			</div>
<?
   	   $number--;
   }
?>
			<div id="page_button">
				<div id="page_num">
<?
	if($page == 1) $lastPage = $page;
	else $lastPage = $page-1;
	if($page == $total_page)$nextPage = $page;
	else $nextPage = $page+1;

	echo "<img src='../image/화살표-1.png' height=10px/><a href='list.php?table=$table&page=$lastPage'> 이전 &nbsp;&nbsp;&nbsp; </a>";
   // 게시판 목록 하단에 페이지 링크 번호 출력
   for ($i=1; $i<=$total_page; $i++)
   {

		if ($page == $i)     // 현재 페이지 번호인 경우 링크 연결 안 함
		{
			echo "<b> $i </b>";
		}
		else
		{
			echo "<a href='list.php?table=$table&page=$i'> $i </a>";
		}
   }
	 echo "<a href='list.php?table=$table&page=$nextPage+1'> &nbsp;&nbsp;&nbsp;다음 </a>
	 <img src='../image/화살표.png' height=10px/>";
?>
				</div>
				<div id="button">
					<a href="list.php?table=<?=$table?>&page=<?=$page?>"><img src="../image/목록-1.png" height=28px></a>&nbsp;
<?
	if($userid)
	{
?>
		<a href="write_form.php?table=<?=$table?>"><img src="../image/글쓰기-1.png" height=28px></a>
<?
	}
?>
				</div>
			</div> <!-- end of page_button -->
        </div> <!-- end of list content -->
		<div class="clear"></div>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
	<? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
