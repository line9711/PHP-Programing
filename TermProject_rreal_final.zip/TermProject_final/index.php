<?
	session_start();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/indexc.css">
</head>

<body>


<div id="every">
	<div id="top">
		<div id="top-2">
		<div id="login">
			<?

                $userid=$_SESSION["userid"];

				if(!$userid)
				{
			?>
					<a href="login/login_form.php"><img src="image/login-1.png" width=100px/></a>
			<?
				}
				else
				{
			?>
					<a href="login/logout.php"><img src="image/logout-1.png" width=100px/></a>
			<?
				}
			?>
		</div>
			<div id="dot"><img src="image/dot-1.png" width=200px/></div>
		</div>
	</div>
	<div id="title"><img src="image/title-1.png" width=250px/></div>
	<div id="introduce">
		<div id="introduce-2"><img src="image/문구-1.png" width=350px></div>
	</div>
  <div id="move">
    <div id="move1"><a href="introduce/introduce.php"><img src="image/모임소개-1.png" width=80px/></a></div>
    <div id="move2"><a href="freeboard/list.php"><img src="image/자유게시판-1.png" width=80px/></a></div>
    <div id="move3"><a href="review/list.php"><img src="image/독서후기-1.png" width=80px/></a></div>
    <div id="move4"><a href="sale/list.php"><img src="image/책거래-1.png" width=90px/></a></div>
  </div>
  <div id="move_book">
    <div id="move_book1"><img src="image/check.png" width=130px/></div>
    <div id="move_book2"><img src="image/pencil.png" width=130px/></div>
    <div id="move_book3"><img src="image/heart.png" width=130px/></div>
    <div id="move_book4"><img src="image/notebook.png" width=130px/></div>
  </div>
</div>

</body>
</html>
