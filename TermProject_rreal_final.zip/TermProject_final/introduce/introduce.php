<? session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/introducec.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title4.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
<div id="wrap">
  <div id="header">
    <? include "../lib/top_menu.php"; ?>
  </div>  <!-- end of header -->
  <div id="title">모임소개</div>
	<div id="col1">
    <image src="../image/readBook1.png" height=350px/>
  </div>
  <div id="col2">
    러버북(Lover Book)이란, 책을 사랑하는 사람들의 모임이란 뜻으로 자신이 읽은 책의 후기를 공유하고 토론 할 수 있는 온라인 커뮤니티 사이트입니다. 책을 좋아하지만 일상생활에서 같이 이야기를 나눌 사람을 찾기 힘든 현대인들에게 자신의 취미생활을 함께 할 수 있는 사람들을 이어주는 역할을 하고 있으며, 책을 읽고 다른 사람의 생각까지 듣고 느끼며 자신의 시야를 넓힐 수 있습니다.<br><br>
    더 많은 사람들이 바쁜 와중에 틈을 내어 책을 읽고, 그 시간만큼은 스마트폰을 내려놓고 책에 집중할 수 있으면 좋겠습니다. 이 장소가 그 계기가 될 수 있기를 바랍니다.
	</div> <!-- end of col2 -->
    <? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
