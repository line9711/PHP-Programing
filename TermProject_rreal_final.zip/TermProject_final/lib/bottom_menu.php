<div id="last"  onmouseover= "this.style.opacity='1'" onmouseout= "this.style.opacity='0'">
  <div id="write">LOVER BOOK</div>
  <div id="movie"><a href="../etc/movie.php"><img src="../image/영상.png" height=35px border="0"></a></div>
  <div id="survey"><a href="#"><img src="../image/설문조사.png" height=35px onclick="window.open('../survey/survey.php', '','scrollbars=no, toolbars=no,width=250,height=270')"></a></div>
  </div>
