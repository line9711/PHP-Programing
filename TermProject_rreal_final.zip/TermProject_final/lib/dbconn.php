<?
    $connect=@mysql_connect( "localhost", "khh", "1234") or
        die( "SQL server에 연결할 수 없습니다.");

    @mysql_select_db("khh_db",$connect);
    @mysql_query("set character_set_client='utf8'",$connect);
    @mysql_query("set character_set_results='utf8'",$connect);
    @mysql_query("set collation_connection='utf8_general_ci'",$connect);

?>
