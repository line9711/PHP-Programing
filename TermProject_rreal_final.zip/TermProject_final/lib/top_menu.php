<div id="logo"><a href="../index.php"><img src="../image/title-11.png" width=150px border="0"></a></div>
<div id="top_right">
  <div id="top_login">
    <?

    $userid=$_SESSION["userid"];

    if(!$userid)
    {
      ?>
    <a href="../login/login_form.php">로그인</a> | <a href="../member/member_form.php">회원가입</a>
    <?
    }
    else
    {
      ?>
      <a href="../login/logout.php">로그아웃</a> | <a href="../login/member_form_modify.php">마이페이지</a>
      <?
    }
    ?>
  </div>
  <div id="menu">
    <div class="menus"><a href="../introduce/introduce.php"><img src="../image/모임소개-2.png" height=40px border="0"></a></div>
    <div class="menus"><a href="../freeboard/list.php"><img src="../image/자유게시판-2.png" height=40px border="0"></a></div>
    <div class="menus"><a href="../review/list.php"><img src="../image/독서후기-2.png" height=40px border="0"></a></div>
    <div class="menus"><a href="../sale/list.php"><img src="../image/책거래-2.png" height=40px border="0"></a></div>
    <div class="menus"><a href="../qna/qna.php"><img src="../image/문의사항-2.png" height=40px border="0"></a></div>
  </div>
</div>
