<? session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/member.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
<div id="wrap">
  <div id="header">
    <? include "../lib/top_menu.php"; ?>
  </div>  <!-- end of header -->
	<div id="col1">
    <image src="../image/login-2.png" width=330px/>
  </div>
  <div id="col2">
    <form  name="member_form" method="post" action="login.php">
		<div id="login_form">
			 <div class="clear"></div>
			 <div id="login">
				<div id="id_input_button">
					<div id="id_pw_title">
						<ul>
						<li><image src="../image/아이디.png" height=40px></li>
						<li><image src="../image/비밀번호.png" height=40px></li>
						</ul>
					</div>
					<div id="id_pw_input">
						<ul>
						<li><input type="text" name="id" class="login_input"></li>
						<li><input type="password" name="pass" class="login_input"></li>
						</ul>
					</div>
					<div id="login_button">
						<input type="image" src="../image/login-3.png" height=65px>
					</div>
				</div>
				<div class="clear"></div>

				<div id="login_line"></div>
				<div id="join_button"><image src="../image/no_join.gif">&nbsp;&nbsp;&nbsp;&nbsp;<a href="../member/member_form.php"><image src="../image/회원가입.png" height=25px></a></div>
			 </div>
		</div> <!-- end of form_login -->
	    </form>
	</div> <!-- end of col2 -->
  <? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
