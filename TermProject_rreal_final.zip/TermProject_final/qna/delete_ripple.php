<?
      include "../lib/dbconn.php";

$num = $_GET["num"];

      $sql = "delete from qna_ripple where num=$num";
      mysql_query($sql, $connect);
      mysql_close();

      echo "
	   <script>
	    location.href = 'qna.php';
	   </script>
	  ";
?>
