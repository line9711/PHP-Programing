<?
	session_start();

$page = $_GET["page"];
$qna_content = $_GET["qna_content"];


	$scale=5;			// 한 화면에 표시되는 글의 개수
	include "../lib/dbconn.php";

	$sql = "select * from qna order by num desc";
	$result = mysql_query($sql, $connect);

	$total_record = @mysql_num_rows($result); // 전체 글의 개수

	// 전체 페이지 수($total_page) 계산
	if ($total_record % $scale == 0)
		$total_page = floor($total_record/$scale);
	else
		$total_page = floor($total_record/$scale) + 1;

	if (!$page)                 // 페이지 번호($page)가 0일때
		$page = 1;              // 페이지 번호를 1로 초기화

	// 페이지 번호에($page)에 따른 시작 레코드 ($start) 계산
	$start = ($page - 1) * $scale;

	$number = $total_record - $start;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/qnac.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title4.css" rel="stylesheet" type="text/css" media="all">
</head>

<body>
	<div id="wrap">
	  <div id="header">
		<? include "../lib/top_menu.php"; ?>
	  </div>
		<div id="title">문의사항</div>
  <div id="content">
	<div id="col2">

		<div id="qna_row1">
       	<form  name="qna_form" method="post" action="insert.php">
			<div id="qna_writer"><span ><img src="../image/화살표.png" height=10px>&nbsp;<?= $usernick; ?></span></div>
			<div id="qna1"><textarea rows="6" cols="85" name="content"></textarea></div>
			<div id="qna2"><input type="image" src="../image/쓰기-1.png" width=110px></div>
		</form>
		</div> <!-- end of qna_row1 -->
<?
   for ($i=$start; $i<$start+$scale && $i < $total_record; $i++)
   {
      mysql_data_seek($result, $i);
      $row = @mysql_fetch_array($result);

	  $qna_id      = $row[id];
	  $qna_num     = $row[num];
      $qna_date    = $row[regist_day];
	  $qna_nick    = $row[nick];

	  $qna_content = str_replace("\n", "<br>", $row[content]);
	  $qna_content = str_replace(" ", "&nbsp;", $qna_content);
?>
		<div id="qna_writer_title">
		<ul>
		<li id="writer_title1"><?= $number ?></li>
		<li id="writer_title2"><?= $qna_nick ?></li>
		<li id="writer_title3"><?= $qna_date ?></li>
		<li id="writer_title4">
		      <?
					if($userid==$qna_id)
			          echo "<a href='delete.php?num=$qna_num'>[삭제]</a>";
			  ?>
		</li>
		</ul>
		</div>
		<div id="qna_content"><?= $qna_content ?>
		</div>
		<div id="ripple">
			<div id="ripple1">덧글</div>
			<div id="ripple2">
<?
	    $sql = "select * from qna_ripple where parent='$qna_num'";
	    $ripple_result = mysql_query($sql);

		while ($row_ripple = @mysql_fetch_array($ripple_result))
		{
			$ripple_num     = $row_ripple[num];
			$ripple_id      = $row_ripple[id];
			$ripple_nick    = $row_ripple[nick];
			$ripple_content = str_replace("\n", "<br>", $row_ripple[content]);
			$ripple_content = str_replace(" ", "&nbsp;", $ripple_content);
			$ripple_date    = $row_ripple[regist_day];
?>
				<div id="ripple_title">
				<ul>
				<li><?= $ripple_nick ?> &nbsp;&nbsp;&nbsp; <?= $ripple_date ?></li>
				<li id="mdi_del">
					<?
						if($userid==$ripple_id)
				            echo "<a href='delete_ripple.php?num=$ripple_num'>[삭제]</a>";
					?>
				</li>
				</ul>
				</div>
				<div id="ripple_content"> <?= $ripple_content ?></div>
<?
		}
?>
				<form  name="ripple_form" method="post" action="insert_ripple.php">
				<input type="hidden" name="num" value="<?= $qna_num ?>">
				<div id="ripple_insert">
				    <div id="ripple_textarea">
						<textarea rows="3" cols="80" name="ripple_content"></textarea>
					</div>
					<div id="ripple_button"><input type="image" src="../image/덧글쓰기.png" height=35px></div>
				</div>
				</form>

			</div> <!-- end of ripple2 -->
  		    <div class="clear"></div>
			<div class="linespace_10"></div>
<?
		$number--;
	 }
	 mysql_close();
?>
			<div id="page_num">
<?
	if($page == 1) $lastPage = $page;
	else $lastPage = $page-1;
	if($page == $total_page)$nextPage = $page;
	else $nextPage = $page+1;

	echo "<img src='../image/화살표-1.png' height=10px/><a href='qna.php?page=$lastPage'> 이전 &nbsp;&nbsp;&nbsp;&nbsp; </a>";

   // 게시판 목록 하단에 페이지 번호 링크 출력
   for ($i=1; $i<=$total_page; $i++)
   {
		if ($page == $i)     // 현재 페이지 번호는 링크 표시 안함
		{
			echo "<b> $i </b>";
		}
		else
		{
			echo "<a href='qna.php?page=$i'> $i </a>";
		}
   }
	 echo "<a href='qna.php?page=$nextPage+1'> &nbsp;&nbsp;&nbsp;&nbsp;다음 </a><img src='../image/화살표.png' height=10px/>";
?>
		</div>
		 </div> <!-- end of ripple -->
	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
	<? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
