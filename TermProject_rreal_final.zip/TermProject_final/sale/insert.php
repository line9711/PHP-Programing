<? session_start(); ?>

<meta charset="utf-8">
<?

$mode = $_GET['mode'];
$num = $_GET['num'];
$page = $_GET['page'];

$hp = $_POST['hp'];
$title = $_POST['title'];
$author = $_POST['author'];
$publisher = $_POST['publisher'];
$content = $_POST['content'];
$upfile=$_POST['upfile[]'];
$date_of_publish =$_POST['date_of_publish'];
$price = $_POST['price'];
$state = $_POST['state'];
$sell_state = $_POST['sell_state'];

$del_ok = $_POST['del_ok'];
$table= "book_list";

$userid=$_SESSION['userid'];
$usernick=$_SESSION['usernick'];
$username = $_SESSION['username'];

include "../lib/dbconn.php";

$sql = "select * from member where id=$userid";
$result = mysql_query($sql, $connect);
$row = @mysql_fetch_array($result);



	if(!$userid) {
		echo("
		<script>
	     window.alert('로그인 후 이용해 주세요.')
	     history.go(-1)
	   </script>
		");
		exit;
	}

	$regist_day = date("Y-m-d (H:i)");  // 현재의 '년-월-일-시-분'을 저장

	// 다중 파일 업로드
  $files = $_FILES["upfile"];
	$count = count($files["name"]);
	$upload_dir = './data/';

	for ($i=0; $i<$count; $i++)
	{
		$upfile_name[$i]     = $files["name"][$i];
		$upfile_tmp_name[$i] = $files["tmp_name"][$i];
		$upfile_type[$i]     = $files["type"][$i];
		$upfile_size[$i]     = $files["size"][$i];
		$upfile_error[$i]    = $files["error"][$i];

		$file = explode(".", $upfile_name[$i]);
		$file_name = $file[0];
		$file_ext  = $file[1];

		if (!$upfile_error[$i])
		{
			$copied_file_name[$i] =$upfile_name[$i];
			$new_file_name.".".$file_ext;
			$uploaded_file[$i] = $upload_dir.$copied_file_name[$i];

			if( $upfile_size[$i]  > 500000 ) {
				echo("
				<script>
				alert('업로드 파일 크기가 지정된 용량(500KB)을 초과합니다 ');
				history.go(-1)
				</script>
				");
				exit;
			}

			if ( ($upfile_type[$i] != "image/gif") &&
				($upfile_type[$i] != "image/jpeg") &&
				($upfile_type[$i] != "image/pjpeg") )
			{
				echo("
					<script>
						alert('JPG와 GIF 이미지 파일만 업로드 가능합니다');
						history.go(-1)
					</script>
					");
				exit;
			}

			if (!move_uploaded_file($upfile_tmp_name[$i], $uploaded_file[$i]) )
			{
				echo("
					<script>
					alert('파일을 지정한 디렉토리에 복사하는데 실패했습니다.');
					history.go(-1)
					</script>
				");
				exit;
			}
		}
	}
	include "../lib/dbconn.php";       // dconn.php 파일을 불러옴

	if ($mode=="modify")
	{
		$num_checked = count($_POST['del_file']);
		$position = $_POST['del_file'];

		for($i=0; $i<$num_checked; $i++)                      // 삭제 표시한 항목
		{
			$index = $position[$i];
			$del_ok[$index] = "y";
		}

		$sql = "select * from $table where num=$num";   // 수정할 레코드 검색
		$result = @mysql_query($sql);
		$row = @mysql_fetch_array($result);

		for ($i=0; $i<$count; $i++)					// 데이터베이스 정보 갱신
		{

			$field_org_name = "file_name_".$i;
			$field_real_name = "file_copied_".$i;

			$org_name_value = $upfile_name[$i];
			$org_real_value = $copied_file_name[$i];
			if ($del_ok[$i] == "y")
			{
				$delete_field = "file_copied_".$i;
				$delete_name = $row[$delete_field];
				$delete_path = "./data/".$delete_name;

				unlink($delete_path);

				$sql = "update $table set $field_org_name = '$org_name_value', $field_real_name = '$org_real_value'  where num='$num'";
				mysql_query($sql, $connect);  // $sql에 저장된 명령 실행
			}
			else
			{
				if (!$upfile_error[$i])
				{
					$sql = "update $table set $field_org_name = '$org_name_value', $field_real_name = '$org_real_value'  where num='$num'";
					mysql_query($sql, $connect);  // $sql에 저장된 명령 실행
				}
			}
		}
		$sql = "update $table set hp='$hp', title='$title', author='$author', publisher= '$publisher', content= '$content', date_of_publish= '$date_of_publish', price= '$price', state= '$state', sell_state = '$sell_state' where num='$num'";
		@mysql_query($sql, $connect);
	}

	else
	{
		$content = htmlspecialchars($content);

		$sql = "insert into $table (name, nick, sell_state, hp, title, author, publisher, content, regist_day, date_of_publish, price, state,";
		$sql .= " file_name_0, file_copied_0) ";
		$sql .= "values('$username', '$usernick', '$sell_state', '$hp', '$title', '$author', '$publisher', '$content','$regist_day', '$date_of_publish', '$price', '$state', ";
		$sql .= "'$upfile_name[0]',  '$copied_file_name[0]')";
		mysql_query($sql, $connect);  //$sql에 저장된 명령 실행
	}
	mysql_close();                // DB 연결 종료

	echo "
	   <script>
	    location.href = 'list.php?table=$table&page=$page';
	   </script>
	";
?>
