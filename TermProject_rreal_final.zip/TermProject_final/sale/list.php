<?
	session_start();
	$table = "book_list";
    $mode = $_GET['mode'];
    $find=$_POST["find"];
    $search = $_POST['search'];
    $page = $_GET["page"];
    $nick = $_SESSION["usernick"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/salec.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title3.css" rel="stylesheet" type="text/css" media="all">
</head>
<?
	include "../lib/dbconn.php";
	$scale=6;			// 한 화면에 표시되는 글의 개수
    if ($mode=="search")
	{
		if(!$search)
		{
			echo("
				<script>
				 window.alert('검색할 단어를 입력하세요');
			     history.go(-1);
				</script>
			");
			exit;
		}
		$sql = "select * from $table where $find like '%$search%' order by num desc";
	}
	else
	{
		$sql = "select * from $table order by num desc";
	}

	$result = mysql_query($sql, $connect);
	$total_record = @mysql_num_rows($result); // 전체 글의 개수

	// 전체 페이지 수($total_page) 계산
	if ($total_record % $scale == 0)
		$total_page = floor($total_record/$scale);
	else
		$total_page = floor($total_record/$scale) + 1;

	if (!$page)
		$page = 1;


	$start = ($page - 1) * $scale;
	$number = $total_record - $start;
?>
<body>
	<div id="wrap">
	  <div id="header">
		<? include "../lib/top_menu.php"; ?>
	  </div>
		<div id="title">책거래</div>
  <div id="content">
	<div id="col2">

		<form  name="board_form" method="post" action="list.php?table=<?=$table?>&mode=search">
		<div id="list_search">
			<div id="list_search1">
				<img src="../image/화살표.png" height=10px/>&nbsp;
				총 <?= $total_record ?> 개의 게시물이 있습니다.  </div>
			<div id="list_search2"><img src="../image/select_search.gif"></div>
			<div id="list_search3">
				<select name="find">
                    <option value='title'>책제목</option>
                    <option value='author'>지은이</option>
                    <option value='content'>내용</option>
                    <option value='nick'>닉네임</option>
				</select></div>
			<div id="list_search4"><input type="text" name="search" value=<?=$search?>></div>
			<div id="list_search5"><input type="image" src="../image/검색-1.png" height=25px></div>
		</div>
		</form>
		<div class="clear"></div>

		<div id="list_content">
<?
   for ($i=$start; $i<$start+$scale && $i < $total_record; $i++, $j++)
   {
		 	$j = 1;
      mysql_data_seek($result, $i);     // 레코드 지칭
      $row = mysql_fetch_array($result); // 하나의 레코드 가져오기

    $image_name    = $row[file_name_0];
		$image_copied = $row[file_name_0];
		$item_num     = $row[num];
	  $item_title     = $row[title];
       $item_now_state = $row[sell_state];
		$item_price    = $row[price];



?>	<div id="total">
		<div class="list">
		<div id="list_item1"><a href="view.php?table=<?=$table?>&num=<?=$item_num?>&page=<?=$page?>">
		<?
					if($image_copied)	{
							$img_name="data/".$image_copied;
							echo "<img src='$img_name' width=180px; height=250px>"."<br><br>";
					}
		?>
		</a></div>
            <div id="list_item1"> <? echo("-") ?> <?= $item_now_state  ?> <? echo("-") ?></div><br>


           <div id="list_item2"> <? echo("< ") ?><?= $item_title ?><?echo(" >") ?></div>

				<div id="list_item3"><?= $item_price ?><? echo("원") ?></div>
			</div>
		</div>
<?
   	   $number--;
   }
?>

			<div id="page_button">
				<div class="clear"></div>
				<div id="page_num">
<?
	if($page == 1) $lastPage = $page;
	else $lastPage = $page-1;
	if($page == $total_page)$nextPage = $page;
	else $nextPage = $page+1;

	echo "<img src='../image/화살표-1.png' height=10px/><a href='list.php?table=$table&page=$lastPage'> 이전 &nbsp;&nbsp;&nbsp; </a>";
   // 게시판 목록 하단에 페이지 링크 번호 출력
   for ($i=1; $i<=$total_page; $i++)
   {

		if ($page == $i)     // 현재 페이지 번호인 경우 링크 연결 안 함
		{
			echo "<b> $i </b>";
		}
		else
		{
			echo "<a href='list.php?table=$table&page=$i'> $i </a>";
		}
   }
	 echo "<a href='list.php?table=$table&page=$nextPage+1'> &nbsp;&nbsp;&nbsp;다음 </a>
	 <img src='../image/화살표.png' height=10px/>";
?>
				</div>
				<div id="button">
					<a href="list.php?table=<?=$table?>&page=<?=$page?>"><img src="../image/목록-1.png" height=28px></a>&nbsp;
<?
	if($userid)
	{
?>
		<a href="write_form.php?table=<?=$table?>"><img src="../image/글쓰기-1.png" height=28px></a>
<?
	}
?>

				</div>
			</div> <!-- end of page_button -->
        </div> <!-- end of list content -->
		<div class="clear"></div>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
	<? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
