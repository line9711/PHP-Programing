<?
session_start();
include "../lib/dbconn.php";


$table= "book_list";
$num = $_GET['num'];
$page = $_GET['page'];

$userid = $_SESSION['userid'];
$usernick = $_SESSION['usernick'];

$regist_day = $_POST['regist_day'];
$subject = $_POST['subject'];
$content = $_POST['content'];

$sql = "select * from $table where num=$num";
$result = mysql_query($sql, $connect);
$row = @mysql_fetch_array($result);

$item_num     = $row[num];
$item_nick    = $row[nick];
$item_id      = $row[id];
$item_hp = $row[hp];
$item_title     = $row[title];
$item_author = $row[author];
$item_publisher = $row[publisher];
$item_content = $row[content];
$item_date_of_publish = $row[date_of_publish];
$item_state = $row[state];
$item_sell_state = $row[sell_state];
$item_price     = $row[price];
$image_name[0]   = $row[file_name_0];
$image_copied[0] = $row[file_copied_0];
$item_date    = $row[regist_day];

for ($i=0; $i<1; $i++)
{
    if ($image_copied[$i])
    {
        $imageinfo = GetImageSize("./data/".$image_copied[$i]);
        $image_width[$i] = $imageinfo[0];
        $image_height[$i] = $imageinfo[1];
        $image_type[$i]  = $imageinfo[2];

        if ($image_width[$i] > 785)
            $image_width[$i] = 785;
    }
    else
    {
        $image_width[$i] = "";
        $image_height[$i] = "";
        $image_type[$i]  = "";
    }
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <meta charset="utf-8">
    <link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/salec.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/title3.css" rel="stylesheet" type="text/css" media="all">
    <script>


        function del(href)
        {
            if(confirm("한번 삭제한 자료는 복구할 수 없습니다.\n정말 삭제하시겠습니까?")) {
                document.location.href = href;
            }
        }
    </script>
</head>

<body>
<div id="wrap">
    <div id="header">
        <? include "../lib/top_menu.php"; ?>
    </div>
    <div id="title">책거래</div>
    <div id="content">
        <div id="col2">

            <div id="view_comment"> &nbsp;</div>
            <div id="view_title">
                <div id="view_title1"><?= $item_title ?></div><div id="view_title2"> <?= $item_nick ?> &nbsp;|&nbsp; <?= $item_date ?> </div>
            </div>

            <div id="view_content">
                <div style="margin-left: 3px" id="pic">
                    <?
                    for ($i=0; $i<1; $i++)
                    {
                        if ($image_copied[$i])
                        {
                            $img_name = $image_copied[$i];
                            $img_name = "./data/".$img_name;
                            $img_width = $image_width[$i];

                            echo "<br><img src='$img_name' width=350px; height=480px>"."<br><br>";
                        }
                    }
                    ?>
                </div>
                <div id="list_item1" style="margin-top:20%; margin-left:10%" id="content">            <!-- 제목 출판사 상태 연락처 작가 출판일 가격 내용 입력  + 내 글 수정,,, 삭제,, 까지,,,,,,! --!>

                    <?
                    echo "★ $item_sell_state ★<br><br>";
                    echo " 작가 : $item_author <br>";
                    echo " 출판사 : $item_publisher <br>";
                    echo " 츨판일 : $item_date_of_publish <br>";
                    echo " 상태 : $item_state <br>";
                    echo " 가격 : $item_price <br>";
                    echo " 연락처 : $item_hp <br>";
                    echo " 내용 : $item_content <br>";
                    ?>
                    </div>
                </div>


            </div>

            <div id="view_button">
                <a href="list.php?table=<?=$table?>&page=<?=$page?>"><img src="../image/목록-1.png" height=28px></a>&nbsp;
                <?
                if($usernick==$item_nick)
                {
                    ?>
                    <a href="write_form.php?table=<?=$table?>&mode=modify&num=<?=$num?>&page=<?=$page?>"><img src="../image/수정-1.png" height=28px></a>&nbsp;
                    <a href="javascript:del('delete.php?table=<?=$table?>&num=<?=$num?>')"><img src="../image/삭제.png" height=28px></a>&nbsp;
                    <?
                }
                ?>
                <?
                if($userid)
                {
                    ?>
                    <a href="write_form.php?table=<?=$table?>"><img src="../image/글쓰기-1.png" height=28px></a>
                    <?
                }
                ?>
            </div>
            <div class="clear"></div>

        </div> <!-- end of col2 -->
    </div> <!-- end of content -->
    <? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
