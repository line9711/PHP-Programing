<?
	session_start();
	include "../lib/dbconn.php";

    $mode = $_GET['mode'];
    $num = $_GET['num'];
    $page = $_GET['page'];
    $table= "book_list";

	if ($mode=="modify")
	{
		$sql = "select * from $table where num=$num";
		$result = mysql_query($sql, $connect);
		$row = mysql_fetch_array($result);

		$item_hp = $row[hp];
		$item_title     = $row[title];
		$item_author = $row[author];
		$item_publisher = $row[publisher];
		$item_content = $row[content];
		$item_date_of_publish = $row[date_of_publish];
		$item_state = $row[state];
        $item_sell_state = $row[sell_state];
		$item_price     = $row[price];
		$item_file_0 = $row[file_name_0];
		$copied_file_0 = $row[file_copied_0];
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="utf-8">
<link href="../css/common.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/salec.css" rel="stylesheet" type="text/css" media="all">
<link href="../css/title3.css" rel="stylesheet" type="text/css" media="all">
<script>
  function check_input()
   {
      if (!document.board_form.title.value)
      {
          alert("제목을 입력하세요");
          document.board_form.title.focus();
          return;
      }

      if (!document.board_form.price.value)
      {
          alert("가격을 입력하세요");
          document.board_form.price.focus();
          return;
      }
      document.board_form.submit();
   }
</script>
</head>

<body>
	<div id="wrap">
	  <div id="header">
		<? include "../lib/top_menu.php"; ?>
	  </div>
		<div id="title">책거래</div>
  <div id="content">
	<div id="col2">
		<div class="clear"></div>

		<div id="write_form_title">
			<img src="../image/write_form_title.gif">
		</div>
		<div class="clear"></div>
<?
	if($mode=="modify")
	{
?>
		<form  name="board_form" method="post" action="insert.php?mode=modify&num=<?=$num?>&page=<?=$page?>&table=<?=$table?>" enctype="multipart/form-data">
<?
	}
	else
	{
?>
		<form  name="board_form" method="post" action="insert.php?table=<?=$table?>" enctype="multipart/form-data">
<?
	}
?>
		<div id="write_form">
			<div class="write_line"></div>
			<div id="write_row1"><div class="col1"> 닉네임 </div><div class="col2"><?=$_SESSION[usernick]?></div>
			<div class="col3">연락처</div>
			<div class="col4"><input type="text" name="hp" value="<?=$item_hp?>" ></div>
			</div>

			<div class="write_line"></div>
			<div id="write_row2"><div class="col1"> 제목 </div><div class="col2"><input type="text" name="title" value="<?=$item_title?>" ></div>
			<div class="col3">작가</div>
			<div class="col4"><input type="text" name="author" value="<?=$item_author?>" ></div>
			</div>

			<div class="write_line"></div>
			<div id="write_row3"><div class="col1"> 출판사 </div><div class="col2"><input type="text" name="publisher" value="<?=$item_publisher?>" ></div>
			<div class="col3">츨판일</div>
			<div class="col4"><input type="text" name="date_of_publish" value="<?=$item_date_of_publish?>" ></div>
			</div>

			<div class="write_line"></div>
			<div id="write_row4"><div class="col1"> 상태 </div><div class="col2"><select name="state">
                        <option value="최상">최상</option>
                        <option value="상">상</option>
                        <option value="중">중</option>
                        <option value="하">하</option>
                    </select></div>

			<div class="col3" style="margin-left:31.3%">가격</div>
			<div class="col4"><input type="text" name="price" value="<?=$item_price?>" ></div>
			</div>

            <div class="write_line"></div>

            <div id="write_row5"><div class="col1"> 거래 가능 여부 </div><div class="col2"><select name="sell_state">

                        <option value="판매중">판매중</option>
                        <option value="거래중">거래중</option>
                        <option value="판매완료">판매완료</option>
                    </select></div>



			<div id="write_row6">

                <div style="margin-top:0.5%; margin-right:90%" class="col1"> 내용</div> <div style="margin-left:17%" class="col2"><textarea rows="15" cols="95" name="content"><?=$item_content?></textarea></div>

            </div>

                <div class="write_line"></div>
			<div style="margin-top:30%" id="write_row6"><div class="col1"> 이미지파일 <br></div> <div class="col2"><input type="file" name="upfile[]"></div>
			</div>

			<div class="clear"></div>
<? 	if ($mode=="modify" && $item_file_0)
	{
?>
			<div class="delete_ok"><?=$item_file_0?> 파일이 등록되어 있습니다.
				 <input type="checkbox" name="del_file[]" value="0"> 삭제</div>
			<div class="clear"></div>
<?
	}
?>
			<div class="write_line"></div>

			<div class="clear"></div>
		</div>

		<div style="margin-top:9%" id="write_button"><a href="#"><img src="../image/완료-1.png" height=28px onclick="check_input()"></a>&nbsp;
								<a href="list.php?table=<?=$table?>&page=<?=$page?>"><img src="../image/목록-1.png" height=28px></a>
		</div>
		</form>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
	<? include "../lib/bottom_menu.php"; ?>
</div> <!-- end of wrap -->

</body>
</html>
