<html>
 <head>
  <title> 설문조사 </title>
  <link rel="stylesheet" href="../css/survey.css" type="text/css">
  <meta charset="utf-8">
  <script>

      function update()
      {
        var vote;
        var length = document.survey_form.composer.length;

        for (var i=0; i<length; i++)
        {
           if (document.survey_form.composer[i].checked == true)
           {
                vote= document.survey_form.composer[i].value;
                break;
           }
        }

        if (i == length)
        {
           alert("문항을 선택하세요!");
           return;
        }

        location.replace("update.php?composer="+vote);  //GET방식
    }

  	  function result()
    {
         location.replace("result.php");
    }
</script>

 </head>





<body>
  <form name=survey_form method=post >
    <table border=0 cellspacing=0 cellpdding=0 width='200' align='center'>
      <input type=hidden name=kkk value=100>
        <tr height=40>
          <td><img src="../image/bbs_poll.gif"></td>
        </tr>
        <tr height=1 bgcolor=#cccccc><td></td></tr>
       <tr height=7><td></td></tr>
       <tr><td><b> 내가 가장 인상깊게 읽은 책은?</b></td></tr>
       <tr><td><input type=radio name='composer' value='ans1' >1. 언어의 온도</td></tr>
       <tr height=5><td></td></tr>
       <tr><td><input type=radio name='composer' value='ans2' >2. 자존감 수업</td></tr>
       <tr height=5><td></td></tr>
       <tr><td><input type=radio name='composer' value='ans3' >3. 4차산업혁명의 시대</td></tr>
       <tr height=5><td></td></tr>
       <tr><td><input type=radio name='composer' value='ans4' >4. 이산 정조대왕</td></tr>
       <tr height=7><td></td></tr>
       <tr height=1 bgcolor=#cccccc><td></td></tr>
       <tr>
       <tr height=7><td></td></tr>
       <tr>
         <td align=middle><img src="../image/b_vote.gif" border="0"  style='cursor:hand'
            onclick=update()></a>
           <img src="../image/b_result.gif" border="0"  style='cursor:hand'
               onclick=result()></a></td></tr>
    </table>
  </form>
</body>
</html>
